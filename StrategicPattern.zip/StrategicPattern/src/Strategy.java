import java.util.ArrayList;
import java.util.List;

public class Strategy {

    public static void main(String[] args) {
    	//create a customer with normal strategy implemented
       
        //let it buy 3 drinks of a $1.0 each

    	// printBill for customer
    	
        // Happy Hour starts
    	// create new customer and set strategy to HappyHourStrategy
    	// repeat the same as above
       
    }
}
