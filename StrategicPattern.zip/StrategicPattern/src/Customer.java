import java.util.*;

public class Customer {
	 //a customer class that purchases a collection of drinks
	 //the bill is decided according to if the hours are normal or happy hour

	 public Customer(/*strategy only, we will use a method for adding drinks*/) {
         
	 }

	 public void add(final double price, final int quantity) {
	    //use our strategy's getActPrice method to get the price of drinks
		//add the price to the arraylist
	 }
	 
	/**
	 *write setter for Strategy
	 */

	 // Payment of bill
	 public void printBill() {
	    double sum = 0;
	    for (Double i : drinks) {
	        sum += i;
	    }
	    System.out.println("Total due: " + sum);
	    drinks.clear();
	 }
}
