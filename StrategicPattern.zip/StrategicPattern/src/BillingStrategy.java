interface BillingStrategy {
    double getActPrice(double rawPrice);
}