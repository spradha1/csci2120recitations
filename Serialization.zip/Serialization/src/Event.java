import java.util.Date;
import java.text.SimpleDateFormat;
import java.text.ParseException;
import java.io.Serializable;

public class Event implements Serializable
{
	//add name, date, venue, details
    
    private SimpleDateFormat dateFormat;

    public Event( String name, String date, String venue, String details)
    {
        //initialize name, date, venue, details
    	
        this.dateFormat = new SimpleDateFormat( "yyyy-MM-dd HH:mm" );
        
        try
        {
            this.date = dateFormat.parse( date );
        }
        catch( ParseException e )
        {
            System.out.println( "Date unparseable using" + this.dateFormat );
        }

    }

    public String getName()
    {
        return this.name;
    }

    public String getDate()
    {
        //return date as string
    }

    public String getVenue()
    {
        return this.venue;
    }

    public String getDetails()
    {
        return this.details;
    }

    public String toString()
    {
       //make a nice readable string to print out all the attributes of the event
       return "";
    }

}