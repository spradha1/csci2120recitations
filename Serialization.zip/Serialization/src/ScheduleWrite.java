import java.io.IOException;
import java.io.FileOutputStream;
import java.io.ObjectOutputStream;

public class ScheduleWrite
{
    public static void main(String[] args)
    {
        //create two events
        
        try{
        	//create a FileOutputStream linked up with a file
        	//create an ObjectOutputStream to write to the file
            
            //write those two events into the file
        	//close file
        }
        
        catch(IOException e){
            //print error message
        }
    }
}
