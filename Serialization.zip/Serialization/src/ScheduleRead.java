import java.io.IOException;
import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class ScheduleRead
{
    public static void main(String[] args)
    {
       //why events not created here?
        try{
        	//create a FileInputStream linked up with a file
        	//create an ObjectInputStream to write to the file
            
            //read the two events out of the file
        	//remember to cast the object into the class you are reading out
        	
        	//print out the events to make sure we read the file correctly
        	//close file
            
        }
        
        catch(IOException e){
            //print error message
        }
        catch(ClassNotFoundException e)
        {
            //print error message
        }
        
        
    }
}